package basicCoding;

public class CharacterToString {
	public static void main(String[] args) {
		char ch='c';
		String s=Character.toString(ch);
		String s1= String.valueOf(ch);
		System.out.println("the string :" +s);
		System.out.println("tha string; " +s1);
		
	}

}
