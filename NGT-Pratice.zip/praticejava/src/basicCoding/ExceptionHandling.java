package basicCoding;

public class ExceptionHandling {
	public static void main(String[] args) {
		System.out.println("program starts");
		int[] myArray= {3,9,6,4,33};
		try {
			System.out.println(myArray[21]);
		} catch (ArrayIndexOutOfBoundsException exception){
			System.out.println(exception);
			
			
			
			
		}
		finally {
			System.out.println("the block is executed");
		}
		
		System.out.println("program ends");
		
		
	}

}
