package basicCoding;

import java.util.Scanner;

public class vowelOrContstant {
	public static void main(String[]args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("enter a alphabit");
		char c=sc.next().charAt(0);
		if(c=='a' || c== 'e' ||c== 'i' ||c=='o') {
			System.out.println("vowel");
			
		}
		else {
			System.out.println("constant");
		}
		
		
		
	}

}
