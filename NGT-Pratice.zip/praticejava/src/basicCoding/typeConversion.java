package basicCoding;

public class typeConversion {

	public static void main(String[] args) {
		int a=25;
		
		// TODO Auto-generated method stub
          double b=a;
          float c= a;
          System.out.println(a+""+b+""+c);
          
	}

}
  