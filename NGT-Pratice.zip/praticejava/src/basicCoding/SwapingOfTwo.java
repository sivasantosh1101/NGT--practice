package basicCoding;

public class SwapingOfTwo {
	public static void main(String[] args, int temp) {
		int a= 22;
		int b=23;
		
		System.out.println("a="+a);
		System.out.println("b= "+b);
		System.out.println("---befor swap--------");
		System.out.println("after swap");
		temp=a;
		a=b;
		b=temp;
		System.out.println("a="+a);
		System.out.println("b="+b);
	}

}