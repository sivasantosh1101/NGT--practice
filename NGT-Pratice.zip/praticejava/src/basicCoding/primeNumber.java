package basicCoding;

import java.util.Scanner;
/*number divisible by one and itself
 * 7/7=1

*/
public class primeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Scanner sc= new Scanner(System.in);
         System.out.println("enter a number");
         int n=sc.nextInt();
         int count =0;
         for(int i=2;i<n;i++) {
        	 if(n%i ==0) {
        		 count=i++;
        		 break;
        	 }
        	 
         }
        	 
        	 
         if (count==0) {
        	 System.out.println("enter   number is prime");
         }
         else {
        	 System.out.println(" not a prime number");
         }
         
         
         
	}

}
