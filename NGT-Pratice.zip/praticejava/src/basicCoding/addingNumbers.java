package basicCoding;

import java.util.Scanner;

public class addingNumbers {
	
	public static void main(String[]args) {
		//System.out.println("enter two numbers");
	//	Scanner sc=new Scanner(System.in);
		int a=1;
		int b= 2;
		
		int c=a+b;
		
		
		System.out.println(c);
	}
			

}
