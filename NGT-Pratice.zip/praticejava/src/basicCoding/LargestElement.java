package basicCoding;

public class LargestElement {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		int arr[]=new int[] {10,20,22,32,23,9};
		int max=arr[0];
		int min=arr[0];
		for(int i=0;i<arr.length;i++) {
			if(arr[i]>max) {
				max=arr[i];
				
			}
			
			
		}
		System.out.println("largest element is :" +max);
		for(int i=0;i<arr.length;i++) {
			if(min>arr[i]) {
				min=arr[i];
				
			}
		}
		System.out.println("least number is :"+min);
	}

}
