package basicCoding;

public class Constructors {
	private double radius;
	public Object get;

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}
	public  double area() {
		return((22/7)*radius*radius);
	}
	public double perimeter() {
		return(2*(22/7)*radius);
	}
	

}
public class GettersAndSetters {
	public static void main(String[] args) {
		
		 Constructors c=new  Constructors();
		c.setRadius(5);
		System.out.println("Radius "+c.get.Radius());
		System.out.println("area"+c.perimeter());
		
		
	}
}
