package basicCoding;

import java.util.Scanner;

/*
 *a=b;
 *b=a;
 * a=b-a;
 * b=a; 
 
 *  a=10
 *  b=20
 *  a=20-10=10;
 *  b=a
 */



public class swapingOfTwoNumbers {
	public static void main(String[]args) {
		
		//System.out.println("enter two number");
		System.out.println("before swap");
		int a=10;
		int b=20;
		System.out.println("a="+a);
		System.out.println("b=" +b);
		
		System.out.println("after swap");
		int temp;
		
		temp=a;
		a=b;
		b=temp;
		System.out.println("a="+a);
		System.out.println("b=" +b);
	
				
		
		
	}
	

}
