package basicCoding;

public class methods {
	public static  void main(String[] args) {
		int sum1= add(2,3);
		int sum2= add(4,9);
		System.out.println(sum1);
		System.out.println(sum2 );
	}

	private static int add(int i, int j) {
		// TODO Auto-generated method stub
		return i+j ;
	}

}
 