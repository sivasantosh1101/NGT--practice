package basicCoding;

import java.util.Scanner;
/*
 * 5*5=25
 */

public class forExample {
	public static void main (String[]args) 
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter number");
	int x= sc.nextInt();
	for(int i=1;i<=10;i++) {
		System.out.println(x +"*" +i+ " = "+i*x );
		
	}
	}

}
