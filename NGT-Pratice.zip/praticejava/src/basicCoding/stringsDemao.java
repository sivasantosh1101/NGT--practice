package basicCoding;

import java.util.Scanner;

public class stringsDemao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner sc= new Scanner(System.in);
       System.out.println("enter  two strings");
       String s1=sc.nextLine();
       String s2=sc.nextLine();
       //System.out.println(s1 + ""+ s2 );
       String s3= s1.concat(s2);
       System.out.println("conncate of threse string is:" +s3);
       int a1= s1.length();
       int a2=s2.length();
       System.out.println("length of s1 string s1:" +a1);
       System.out.println("length of s2 string s2:" +a2);
       
	}

}
