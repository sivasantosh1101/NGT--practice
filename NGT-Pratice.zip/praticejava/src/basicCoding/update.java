package basicCoding;

import java.util.Scanner;

public class update {
	public static void main(String[]args) {
		Scanner sc= new Scanner(System.in);
		String str="vineesha";
		if(str.isEmpty()) {
			System.out.println("enter name");
			str=sc.nextLine();
			
		}
		
		else{
			
			System.out.println(str + " gud nyt");
		}
	}

}
