package basicCoding;

public class array 
{
	public static void main(String[]args)
	{
	 int nums[]= new int[3];
	    nums[0]=23;
	    nums[1]=33;
		nums[2]=44;
		//nums[1]=55;
		for(int i=0;i<3;i++) {
			
		
		System.out.println(nums[i]);
		}
	
	}
	
}
