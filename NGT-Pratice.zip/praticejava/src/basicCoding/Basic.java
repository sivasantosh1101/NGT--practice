package basicCoding;

public class Basic {
	public static void main(String[] args) {
		
		int age = 17;
		String name = "Sruthi";
		float money= 1000.45f;
		double invest = 1232.23;
		boolean isalive = true;
		short lengh = 32;
		long total = 329865;
		char start = 'T';
		byte last = 2;
		
		System.out.println(age + "\n" + name + "\n" + money + "\n" + invest +
				"\n" + isalive + "\n" + lengh + "\n" + total + "\n" + start
				+ "\n" + last );
	}

}
