package basicCoding;

import java.util.Scanner;

/*
 * BETWEEN TO PRIME
 * 1 to 100
 * number read
 * condition ;
 *            prime number
 *   			between numbers
 *   one and itself
 * 7/7
 
 */

public class betweenTwoPrimeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("enter  two digits where you want those prime numbers  : ");
		int a=sc.nextInt();
		int b=sc.nextInt();
		 int count =0;
		for( int i=a;i<b;i++) {
			if(( a+1)%i==0) {
				count =i++;
				break;
				
			}
			if(count==0) {
				System.out.println("prime numbers are: " );
			}
			
		}
		
          
	}

}
