package basicCoding;

import java.util.Scanner;

public class stringBuffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        // Scanner sc= new Scanner(System.in);
        // System.out.println("enter  a  string");
         StringBuffer  sbf= new StringBuffer("siva kumar");
         sbf.append("=santosh");
         sbf.delete(6, 11);
       //  sbf.replace(5, 6, 11);
         
         System.out.println(sbf);
	}

}
