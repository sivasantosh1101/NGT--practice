package basicCoding;

public class AccountHolderObjects {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccountHolder tej=new AccountHolder();
		tej.FirstName="tej";
		tej.LastName="sai";
		tej.age=32;
		tej.AccountBalance=2000;
		tej.testEligibleForCreditCard();
		System.out.println("is tej eligible : "+tej.EligibleForCreditCard);
		
		
	}

}
