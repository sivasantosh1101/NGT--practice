package basicCoding;

import java.util.Arrays;

public class StringArrayToChar {
	public static void main(String[] args) {
		
		String sive="lost in the world";
		char[] chrs=sive.toCharArray();
		System.out.println(Arrays.toString(chrs));
		
	}

}
