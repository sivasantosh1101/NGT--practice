package basicCoding;

import java.util.Scanner;

public class nameString {
	public static void main (String[] args) {
		Scanner sc= new Scanner(System.in);
		String  str="";
		while (str.isEmpty()) {
			System.out.println("enter your name");
			str=sc.nextLine();
			
		}
		System.out.println(str + " good night");
		
		
	}

}
