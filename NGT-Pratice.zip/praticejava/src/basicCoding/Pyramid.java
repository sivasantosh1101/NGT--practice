package basicCoding;

public class Pyramid {
	public static void main(String[] args) {
		int no=5;
		for(int line=1;line<=no;line++) {
			for(int space=1;space<=no-line;space++) {
				System.out.print(" ");
			}
			for( int star=1;star<=line;star++) {
				System.out.print("* ");
			}
			
			System.out.println();
		}
		
		
	}

}
