package basicCoding;

import java.util.Scanner;

/*
 AVG=SUM/TN;
 TN?
 SUM?
 GIVE ELEMENT
 
 
 */

public class AverageArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("entre element number:");
		int x= sc.nextInt();
		double[] arr=new double[x];
		System.out.println("enter "+x+" elements :");
		
		double sum=0;
		for(int i=0;i<x;i++) {
			arr[i]=sc.nextInt();
			sum+=arr[i];
		}
			System.out.println("avg of the array is:"+sum/x);
			
			
		
		
		
	}
	

}
