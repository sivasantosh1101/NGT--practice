package basicCoding;

public class factorial {
	public  static void main(String[]args) {
		int num=2;
		num=num-1;
		 
		while(num==0) {
			
			
			
		}
		
		
		
	}

}
