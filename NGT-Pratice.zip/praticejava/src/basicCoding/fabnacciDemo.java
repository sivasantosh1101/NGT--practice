package basicCoding;
/*
 * 1,1,2,3,5,8
 */

import java.util.Scanner;

public class fabnacciDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner sc= new Scanner(System.in);
    System.out.println("enter a number");
    int n= sc.nextInt();
    int f=1,s=1,t;
   
    System.out.println(f);
    System.out.println(s);
	
    for( int i=3;i<=n;i++) {
     t=f+s;
    
    System.out.println(t);
    f=s;
    s=t;
    }
	
    }
}
