package basicCoding;

public class AccountHolder {

	public static void main(String[] args) {
		String FirstName;
		String LastName;
		String EligibleForCreditCard;
		int age;
		int AccountBalance;
		 	
	}

	
	
	
public static  testEligibleForCreditCard() {
	if(age>25 && AccountBalance >=200) {
		boolean EligibleForCreditCard = true;
		
	}

	
}
}
