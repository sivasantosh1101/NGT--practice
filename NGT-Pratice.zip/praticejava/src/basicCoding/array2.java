package basicCoding;

public class array2 {
public static void main(String[]args) {
	int nums[]=  {1,2,3,4,5};
	for(int i=0;i<5;i++) {
	System.out.println("" +nums[i]);
	}
}
}
