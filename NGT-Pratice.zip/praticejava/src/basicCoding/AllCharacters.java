package basicCoding;

//import java.util.Scanner;

public class AllCharacters {
	public static void main(String[] args) {
		// Scanner reader= new Scanner(System.in);
		
		for(char c='A';c<='Z';c++)  {
			System.out.print(c +" ");
			
		}
	}

}
