package basicCoding;

import java.util.Scanner;
/*
 * enter the values a,b,ci,c 
 * c[i]=a
 * ci=b
 * ci=a+b
 *  
 * 
 */

public class ConcatnationOfTwoArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 Scanner sc= new Scanner(System.in);
	 System.out.println("enter the number of length a ");
	 int a=sc.nextInt();
	 
	 System.out.println("enter the lenght in b");
	 int b=sc.nextInt();
	 int c= a+b;
	 int[] n1= new int[a];
	 int[] n2=new int[b];
	 int[]n3= new int[c];
	 
	 System.out.println("enter the values" +a+"the elements:" );
	 for(int i=0;i<a;i++) {
		 n1[i]=sc.nextInt();
		 System.out.println("enter the values" +b+"the elements:" );
		 for(int i1=0;i1<b;i1++) {
			 n2[i1]=sc.nextInt();
			 
			for(int i11=0;i11<a;i11++) {
				n3[i11]=n1[i11];
			}
			for (int i11=0;i11<b;i11++) {
				n3[a+i11]=n2[i11];
			}
	 
		 }
		 System.out.println("mergearray ");
		  for (int i1=0;i1<n3.length;i1++) {
			System.out.println(n3[i1]+" ");  
		  }
			  
		  }
	 /*int ci=0;
	 ;
	 System.out.println("enter the values int the elements b :");
	 int [] c=new int[a.length()+b.length()];
	 int [] arr= new int[a];
	 for( int i=0;i<=a;i++) {
		 
		c [ci]=a[i];
		 i++;
		 
	 }*/
	 
	
	 

	}

}
