package basicCoding;

public class AscendingOrder {
	public static void main(String[] args) {
		int arr[]= {1,22,33,1,4,5,0,3,0};
		 int num=arr[0],max;
		for(int i=0;i<arr.length;i++) {
			
			if(num<arr[i]) {
				
				arr[i]++;
				
			}
		}
		System.out.println("sorting" +arr);
	}

}
