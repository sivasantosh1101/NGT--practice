package basicCoding;

public class CheckNumberOfVowles {
	public static void main(String[] args) {
		
		String str=" my name is siva santosh kumar";
		int vCount=0 ,cCount=0;
		str=str.toLowerCase();
		for (int i=0;i<str.length();i++) {
			if(str.charAt(i)=="a" ||str.charAt(i)=="e"||str.charAt(i)=="i"||str.charAt(i)=="o"||str.charAt(i)=="u") {
				vCount++;
				
			
			
		}
			else if(str.charAt(i)>="a" && str.charAt(i)<="z") {
				cCount++;
				
			}
		
	}

}
}
