package basicCoding;

public class Alphanumeric {

}
