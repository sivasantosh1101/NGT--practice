package basicCoding;
/*121
 * abcba;
 * i>j;
 * first=last ;
 * i++
 * j--
 * 
  
 
 * 
 */

public class palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="bccba";
		int i=0,j=s.length()-1;
		while(i<j) {
			if(( s.charAt(i))!= (s.charAt(j))){
				System.out.println("not a palindrome");
				System.exit(0);
				i++;
				j--;
			}
			else{
				System.out.println("it is apalindrome");
			}
			
			
		}
		
		
	}

}
